/**
 * \file
 *
 * \brief Non-Volatile Memory Controller - fuse setting
 *
 * Copyright (c) 2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip
 * software and any derivatives exclusively with Microchip products.
 * It is your responsibility to comply with third party license terms applicable
 * to your use of third party software (including open source software) that
 * may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE
 * LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
 * LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
 * SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT
 * ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
 * RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
 * THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * \asf_license_stop
 *
 */

#include <atmel_start.h>

#define _NVM_USER_ROW_BASE    0x804000

/* Struct for user area (first 32 bytes, for BOD, WDT) */
typedef union {
	struct {
		/* word 0*/
		uint32_t BOD33_DIS:1;       /* bit: 0 */
		uint32_t BOD33USERLEVEL:8;  /* bit: 8:1 */ 
		uint32_t BOD33_ACTION:2;    /* bit: 10:9 */ 
		uint32_t BOD33_HYST:4;      /* bit: 14:11 */ 
		uint32_t :17;
		/*word 1*/
		uint32_t :16;
		uint32_t WDT_ENABLE:1;      /* bit: 48 */ 
		uint32_t WDT_ALWAYSON:1;    /* bit: 49 */ 
		uint32_t WDT_PER:4;         /* bit: 53:50 */ 
		uint32_t WDT_WINDOW:4;      /* bit: 57:54 */ 
		uint32_t WDT_EWOFFSET:4;    /* bit: 61:58 */ 
		uint32_t WDT_WEN:1;         /* bit: 62 */ 
	} bit;                          /* Structure used for bit access */
	struct {
		uint32_t word[8];
	} word;                         /* Structure used for word access */
} user_area_type;

int32_t user_fuse_read(uint32_t *buf);
int32_t user_fuse_write(const uint32_t *_row);
