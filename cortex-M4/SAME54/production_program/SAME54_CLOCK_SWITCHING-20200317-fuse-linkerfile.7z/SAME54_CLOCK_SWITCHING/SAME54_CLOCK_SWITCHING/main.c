/**
 * \file
 *
 * \brief Application implement
 *
 * Copyright (c) 2018 Microchip Technology Inc. and its subsidiaries.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip
 * software and any derivatives exclusively with Microchip products.
 * It is your responsibility to comply with third party license terms applicable
 * to your use of third party software (including open source software) that
 * may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE
 * LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
 * LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
 * SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT
 * ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
 * RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
 * THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * \asf_license_stop
 *
 */
/*
 * Support and FAQ: visit <a href="https://www.microchip.com/support/">Microchip Support</a>
 */

#include <atmel_start.h>
#include <fuse_same5xd5x.h>

//=========================================================================================
void change_mclk_div(uint32_t div);

/*
 * \brief Change main clock divide
 *
 * \param div - MCLK_CPUDIV_DIV_DIV1,
 *              MCLK_CPUDIV_DIV_DIV2,
 *              MCLK_CPUDIV_DIV_DIV4,
 *              ...
 *              MCLK_CPUDIV_DIV_DIV128
 */
void change_mclk_div(uint32_t div)
{
	void *hw = (void *)MCLK;

	hri_mclk_write_CPUDIV_reg(hw, div);
	while (!hri_mclk_get_INTFLAG_CKRDY_bit(hw));
}

//=========================================================================================
/* Fuse configuration */
#define CFG_BOD33_DIS       0
#define CFG_BOD33_ACTION    SUPC_BOD33_ACTION_RESET_Val

#define CFG_WDT_ENABLE      0
#define CFG_WDT_PER         WDT_CONFIG_PER_CYC16384_Val

user_area_type fuse_buf;

// Method 2 to set fuse with user row section
__attribute__((section(".userrowsec"))) const uint32_t nvm_user_row[] =
{
	0xFFFF9239, // 0xFFFF9239, 0xFFFF9238
	0xAAA8FF80, // 0xAAA8FF80, 0xAAA9FF80
	0xFFFFFFFF
};


//=========================================================================================
/*
 * Main function:
 *   - Demonstrate how to change main clock with different CPUDIV
 *   - Use event system to toggle LED
 */
int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Start timer */
	timer_start(&TIMER_0);

	/* Initial clock setting:
	 *     - DPLL0: 96MHz
	 *     - GCLK0: 96MHz
	 *     - MCLK:  12MHz (96 / 8)
	 */
	printf("System main clock starts to run at 12MHz! CPUDIV = 8.\r\n");

	/* Demo code for fuse setting with APIs */
#if 0
	/* Read fuse */
	user_fuse_read((uint32_t *)&fuse_buf);

	/* Update fuse if needed */
	if ( (fuse_buf.bit.BOD33_DIS != CFG_BOD33_DIS) || (fuse_buf.bit.BOD33_ACTION != CFG_BOD33_ACTION) ||
		 (fuse_buf.bit.WDT_ENABLE != CFG_WDT_ENABLE) || (fuse_buf.bit.WDT_PER != CFG_WDT_PER)
	   ) {
		fuse_buf.bit.BOD33_DIS = CFG_BOD33_DIS;
		fuse_buf.bit.BOD33_ACTION = CFG_BOD33_ACTION;

		fuse_buf.bit.WDT_ENABLE = CFG_WDT_ENABLE;
		fuse_buf.bit.WDT_PER = CFG_WDT_PER;

		/* Write fuse */
		user_fuse_write((uint32_t *)&fuse_buf);

		/* Reset system to reload fuse */
		NVIC_SystemReset();
	}
#endif

	/* Demo code for MCLK frequency change */
#if 1
	while (1) {
		/* CPU does nothing here since Event system is handling LED toggle.
		   Other Application tasks can make use of CPU bandwidth */

		delay_ms(5000);     /* No need to adjust as main clock is no change yet (CONF_CPU_FREQUENCY) */
		change_mclk_div(MCLK_CPUDIV_DIV_DIV1);
		printf("Switch main clock to 96MHz! CPUDIV = 1\r\n");

		delay_ms(5000*8);    /* Adjust delay function because main clock change */
		change_mclk_div(MCLK_CPUDIV_DIV_DIV8);
		printf("Switch main clock to 12MHz! CPUDIV = 8\r\n");
	}
#endif
}
