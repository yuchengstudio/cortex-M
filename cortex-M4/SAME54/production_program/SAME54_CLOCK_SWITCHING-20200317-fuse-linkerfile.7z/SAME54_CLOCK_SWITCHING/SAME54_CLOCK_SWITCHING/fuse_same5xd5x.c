/**
 * \file
 *
 * \brief Non-Volatile Memory Controller - fuse setting
 *
 * Copyright (c) 2020 Microchip Technology Inc. and its subsidiaries.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip
 * software and any derivatives exclusively with Microchip products.
 * It is your responsibility to comply with third party license terms applicable
 * to your use of third party software (including open source software) that
 * may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE
 * LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
 * LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
 * SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT
 * ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
 * RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
 * THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * \asf_license_stop
 *
 */

#include <fuse_same5xd5x.h>
#include <string.h>


/** \ Read first 32 bytes of user row
 *  \param[in] buf Buffer pointer to store user row data.
 */
int32_t user_fuse_read(uint32_t *buf)
{
	ASSERT(buf);

	/* Copy data */
	memcpy((uint8_t *)buf, ((uint8_t *)_NVM_USER_ROW_BASE), 32);
	
	return ERR_NONE;
}


/** \ Write first 32 bytes of user row
 *  \param[in] _row Pointer to user row data.
 */
int32_t user_fuse_write(const uint32_t *_row)
{
	Nvmctrl *hw    = NVMCTRL;
	uint32_t ctrla = hri_nvmctrl_read_CTRLA_reg(NVMCTRL);
	uint32_t i;

	/* Denied if Security Bit is set */
	if (DSU->STATUSB.bit.PROT) {
		return ERR_DENIED;
	}

	/* Do Save */

	/* - Prepare. */
	while (!hri_nvmctrl_get_STATUS_READY_bit(hw)) {
		/* Wait until this module isn't busy */
	}
	hri_nvmctrl_clear_CTRLA_WMODE_bf(NVMCTRL, NVMCTRL_CTRLA_WMODE_Msk);

	/* - Erase AUX row. */
	hri_nvmctrl_write_ADDR_reg(hw, (hri_nvmctrl_addr_reg_t)_NVM_USER_ROW_BASE);
	hri_nvmctrl_write_CTRLB_reg(hw, NVMCTRL_CTRLB_CMD_EP | NVMCTRL_CTRLB_CMDEX_KEY);
	while (!hri_nvmctrl_get_STATUS_READY_bit(hw)) {
		/* Wait until this module isn't busy */
	}

	for (i = 0; i < 2; i++) { /* 2 Quad words for User row: 2 * (4 bytes * 4) = 32 bytes */
		/* - Page buffer clear & write. */
		hri_nvmctrl_write_CTRLB_reg(hw, NVMCTRL_CTRLB_CMD_PBC | NVMCTRL_CTRLB_CMDEX_KEY);
		while (!hri_nvmctrl_get_STATUS_READY_bit(hw)) {
			/* Wait until this module isn't busy */
		}
		*(((uint32_t *)NVMCTRL_USER) + i * 4)     = _row[i * 4];
		*(((uint32_t *)NVMCTRL_USER) + i * 4 + 1) = _row[i * 4 + 1];
		*(((uint32_t *)NVMCTRL_USER) + i * 4 + 2) = _row[i * 4 + 2];
		*(((uint32_t *)NVMCTRL_USER) + i * 4 + 3) = _row[i * 4 + 3];

		/* - Write AUX row. */
		hri_nvmctrl_write_ADDR_reg(hw, (hri_nvmctrl_addr_reg_t)(_NVM_USER_ROW_BASE + i * 16));
		hri_nvmctrl_write_CTRLB_reg(hw, NVMCTRL_CTRLB_CMD_WQW | NVMCTRL_CTRLB_CMDEX_KEY);
		while (!hri_nvmctrl_get_STATUS_READY_bit(hw)) {
			/* Wait until this module isn't busy */
		}
	}

	/* Restore CTRLA */
	hri_nvmctrl_write_CTRLA_reg(NVMCTRL, ctrla);

	return ERR_NONE;
}
