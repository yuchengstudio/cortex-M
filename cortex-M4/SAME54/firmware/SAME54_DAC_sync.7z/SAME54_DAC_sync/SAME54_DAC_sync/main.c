#include <atmel_start.h>
uint16_t i = 0x3ff;
int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	dac_sync_enable_channel(&DAC_0, 0);
	/* Replace with your application code */
	
	dac_sync_write(&DAC_0, 0, &i, 1);
	while (1) {
	
	//dac_sync_write(&DAC_0, 0, &i, 1);
		
	for (;;) {
		//dac_sync_write(&DAC_0, 0, &i, 1);
		//i = (i + 1) % 1024;
	}
	}
	
}
