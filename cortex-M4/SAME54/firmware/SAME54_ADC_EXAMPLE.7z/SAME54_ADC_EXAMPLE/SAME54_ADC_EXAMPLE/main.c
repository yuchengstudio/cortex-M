#include <atmel_start.h>

uint8_t ADC_result_buffer[2];
int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	adc_sync_enable_channel(&ADC_0, 6);

	/* Replace with your application code */
	while (1) {
		
		printf("hello world! \r\n");
		delay_ms(1000);
		adc_sync_set_inputs(&ADC_0, 0x06, 0x18, 0);
		adc_sync_read_channel(&ADC_0, 0, ADC_result_buffer, 2);
		printf("the ADC1[AN6] result is: 0x%x, 0x%x,\n\r", ADC_result_buffer[0], ADC_result_buffer[1]);
		
		adc_sync_set_inputs(&ADC_0, 0x00, 0x18, 0);
		adc_sync_read_channel(&ADC_0, 0, ADC_result_buffer, 2);
		printf("the ADC1[AN0] result is: 0x%x, 0x%x,\n\r", ADC_result_buffer[0], ADC_result_buffer[1]);
	}
}
