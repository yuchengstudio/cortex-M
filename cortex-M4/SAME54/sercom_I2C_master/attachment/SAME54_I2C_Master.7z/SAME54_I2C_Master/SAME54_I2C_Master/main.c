#include <atmel_start.h>
volatile bool I2C_Rx_flag = false;
volatile bool I2C_Tx_flag = false;
uint8_t i2c_rx_buf[12];
struct io_descriptor *I2C_0_io;

uint8_t i2c_tx_buf[12] = "hello world!";

void I2C_0_tx_complete(struct i2c_m_async_desc *const i2c)
{
	I2C_Tx_flag = true;
}


void I2C_0_rx_complete(struct i2c_m_async_desc *const i2c)
{
	I2C_Rx_flag = true;
}




int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	//I2C application inithlize 
	i2c_m_async_get_io_descriptor(&I2C_0, &I2C_0_io);
	i2c_m_async_enable(&I2C_0);
	i2c_m_async_register_callback(&I2C_0, I2C_M_ASYNC_TX_COMPLETE, (FUNC_PTR)I2C_0_tx_complete);
	i2c_m_async_register_callback(&I2C_0, I2C_M_ASYNC_RX_COMPLETE, (FUNC_PTR)I2C_0_rx_complete);
	i2c_m_async_set_slaveaddr(&I2C_0, 0x12, I2C_M_SEVEN);
	
	//I2C read data
	//io_read(I2C_0_io, i2c_rx_buf, 2);
	
	//I2C Write data
	io_write(I2C_0_io, i2c_tx_buf, 12);
	while (1) {
		if (I2C_Rx_flag == true)
		{
			I2C_Rx_flag = false;
			//io_read(I2C_0_io, i2c_rx_buf, 4);
			//delay_ms(100);
		}
		
		io_write(I2C_0_io, i2c_tx_buf, 12);
		delay_ms(100);
		
	}
}
