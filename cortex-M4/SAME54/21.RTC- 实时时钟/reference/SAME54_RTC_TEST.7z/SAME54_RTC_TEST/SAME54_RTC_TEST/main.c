#include <atmel_start.h>

struct calendar_date_time data_time;

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	CALENDAR_0_example();
	/* Replace with your application code */
	while (1) {
		
		calendar_get_date_time(&CALENDAR_0, &data_time);
		delay_ms(1000);
		
	}
}
