//����Ŀ�Ĳ���calģʽ�ܷ���backupģʽ�¹���  
//ʵ�ʲ����� ��Ҫ��ʱ��洢��flash����backup�Ĵ�����
#include <atmel_start.h>


 static struct calendar_alarm alarm;
  struct io_descriptor *io;
uint8_t time0[3];
volatile uint8_t  flag=0;
static void alarm_cb(struct calendar_descriptor *const descr)
{
	gpio_toggle_pin_level(PC18);
    io_write(io,time0,3);
	//__set_FAULTMASK(1);
	//NVIC_SystemReset();//��ֹ�������  ���������ϵͳ��λ
}

static void tx_cb(const struct usart_async_descriptor *const io_descr)
{
	flag=1;
}

int main(void)
{
	int32_t ret =0;
	/* Initializes MCU, drivers and middleware */
		//if (hri_rtcmode2_read_SYNCBUSY_reg(RTC)) {
			//hri_rtcmode2_write_CTRLA_reg(RTC, RTC_MODE2_CTRLA_SWRST);//RTCʵ��������λ
		//}
		struct calendar_date date;
		struct calendar_time time;
		struct calendar_date_time TIM;
		//convert_timestamp_to_datetime(CALENDAR_0,);
	//	calendar_get_date_time(&CALENDAR_0,&TIM);
		//time0[0]=TIM.time.hour;
		//time0[1]=TIM.time.min;
		//time0[2]=TIM.time.sec;
	    atmel_start_init();
		usart_async_register_callback(&USART_1, USART_ASYNC_TXC_CB, tx_cb);
		usart_async_get_io_descriptor(&USART_1, &io);
		usart_async_enable(&USART_1);
		//hri_rtcmode0_write_CTRLA_reg(RTC, RTC_MODE0_CTRLA_SWRST);//RTCʵ��������λ 
		
		calendar_get_date_time(&CALENDAR_0,&TIM);
		
    	date.year  = 2019;
    	date.month = 7;
    	date.day   = 19;

    	time.hour = 17;
    	time.min  = 36;
    	time.sec  = 00;
        calendar_enable(&CALENDAR_0);
    	calendar_set_date(&CALENDAR_0, &date);
    	calendar_set_time(&CALENDAR_0, &time);

        
    	alarm.cal_alarm.datetime.time.sec = 20;//����ƥ�䵽�����˼�Ƿ��ӵ�10s�ж�һ�� ������ÿ10s�ж�һ��
		alarm.cal_alarm.datetime.time.min = 37;
		alarm.cal_alarm.datetime.time.hour= 17;
		alarm.cal_alarm.datetime.date.day = 19;
		alarm.cal_alarm.datetime.date.month=7;
		alarm.cal_alarm.datetime.date.year=2019;
    	alarm.cal_alarm.option            = CALENDAR_ALARM_MATCH_HOUR;
    	alarm.cal_alarm.mode              = REPEAT;
        
    	ret = calendar_set_alarm(&CALENDAR_0, &alarm, alarm_cb);
	    calendar_get_date_time(&CALENDAR_0,&TIM);
		time0[0]=TIM.time.hour;
		time0[1]=TIM.time.min;
		time0[2]=TIM.time.sec;
		io_write(io,time0,3);
		flag=0;
		while(flag==0);
	/* Replace with your application code */
	while (1) {
		while (!hri_pm_read_INTFLAG_reg(PM));
		hri_pm_write_BKUPCFG_reg(PM, PM_BKUPCFG_BRAMCFG(0x1));
		_set_sleep_mode(6);
		__DSB();
		__WFI();
	}

}
