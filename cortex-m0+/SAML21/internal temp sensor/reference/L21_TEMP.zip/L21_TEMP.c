//ADC0
#define ADC0_PA02		0x00
#define ADC0_PA03		0x01
#define ADC0_PB08		0x02
#define ADC0_PB09		0x03
#define ADC0_PA04		0x04
#define ADC0_PA05		0x05
#define ADC0_PA06		0x06
#define ADC0_PA07		0x07
#define ADC0_PB00		0x08
#define ADC0_PB01		0x09
#define ADC0_PB02		0x0A
#define ADC0_PB03		0x0B
#define ADC0_PB04		0x0C
#define ADC0_PB05		0x0D
#define ADC0_PB06		0x0E
#define ADC0_PB07		0x0F
#define ADC0_PA08		0x10
#define ADC0_PA09		0x11
#define ADC0_PA10		0x12
#define ADC0_PA11		0x13
#define MCU_TEMP		0x18

//TEMPERATURE
#define TEMP_M		MCU_TEMP

#define AVG_COUNT	64u

uint8_t ROOM_TEMP_VAL_INT,ROOM_TEMP_VAL_DEC;
uint8_t HOT_TEMP_VAL_INT,HOT_TEMP_VAL_DEC;
int8_t ROOM_INT1V_VAL,HOT_INT1V_VAL;
uint16_t ROOM_ADC_VAL,HOT_ADC_VAL;
float tempC;
float tempF;

uint32_t temp_data_old = 0;
uint32_t temp_data_last[AVG_COUNT] = {0};

uint8_t buffer[2];

struct _adc_average
{
	uint16_t real_data;
	uint16_t last_data;
	uint8_t time_limit;
};

struct _adc_average temp_adc=
{
	.real_data = 0,
	.last_data = 0,
	.time_limit = 0
};

void l21_temperature_init(void)
{
	hri_adc_clear_SAMPCTRL_OFFCOMP_bit(ADC);//ADC.SAMPCTRL.OFFCOMP=0
	hri_supc_set_VREF_TSEN_bit(SUPC);//enable temperature sensor
}

void enable_adc(void)
{
	l21_temperature_init();
	(void)adc_sync_enable_channel(&ADC_0, 0);
}

void set_adc_pin(void)
{
	(void)adc_sync_set_inputs(&ADC_0,TEMP_M,GND_VREF, 0);
}
void read_adc_result(void)
{
	(void)adc_sync_read_channel(&ADC_0, 0, (uint8_t *)&temp_adc.real_data, 2);
}

uint16_t temp_average_calculate(uint16_t temp_tmp)
{
	static uint16_t data_end;
	static uint8_t time_tmp = 0;
	static int8_t temp_init_count = 2;
	//64������ѭ���ƶ�ʽƽ��
	if(!temp_init_count)//����ÿ�γ�ʼ������ȡ��Temp ADCֵǰ����ƫ��󣬶���
	{
		//ÿ����һ�Σ�ѭ���滻һ������
		temp_data_old -= temp_data_last[time_tmp];
		temp_data_last[time_tmp] = temp_tmp;
		temp_data_old += temp_data_last[time_tmp];
		//ADCֵȡƽ��
		data_end = (uint16_t)(temp_data_old / AVG_COUNT);
		
		time_tmp ++;
		if(time_tmp == AVG_COUNT)
		{
			time_tmp = 0;
		}
		//����ADCƽ��ֵ
		return data_end;
	}
	else
	{
		temp_init_count --;
		return 0;
	}
}
//MCU Internal temperature parameter
void temp_local_parameter(void)
{
	uint8_t temp_parameter_tmp[8];
	
	_flash_read(&FLASH_0.dev,NVM_Temperature_Log_Row,(uint8_t *)(&temp_parameter_tmp[0]),8);
	
	//					bit0-7
	ROOM_TEMP_VAL_INT = temp_parameter_tmp[0];
	//					bit8-11
	ROOM_TEMP_VAL_DEC = temp_parameter_tmp[1] & 0x0F;
	//					bit12-19
	HOT_TEMP_VAL_INT = ((temp_parameter_tmp[1] & 0xF0) >> 4)+ ((temp_parameter_tmp[2] & 0x0F) << 4);
	//					bit20-23
	HOT_TEMP_VAL_DEC = (temp_parameter_tmp[2] & 0xF0) >> 4;
	//					bit24-31
	ROOM_INT1V_VAL = temp_parameter_tmp[3];
	//					bit32-39
	HOT_INT1V_VAL = temp_parameter_tmp[4];
	//					bit40-51
	ROOM_ADC_VAL = (uint16_t)((((temp_parameter_tmp[6] & 0x0F) << 8)+ temp_parameter_tmp[5]) / 2.5);
	//					bit52-63
	HOT_ADC_VAL = (uint16_t)(((temp_parameter_tmp[7] << 4) + ((temp_parameter_tmp[6] & 0xF0) >> 4)) / 2.5);
	
	temp_data_old = ROOM_ADC_VAL*AVG_COUNT;
	for (uint8_t array_count = 0;array_count < AVG_COUNT;array_count++)
	{
		temp_data_last[array_count] = ROOM_ADC_VAL;
	}
}

unsigned short int l21_temperature_calculate(unsigned short int temp_adc_sample)
{
	float tempR;       /* Production Room Temperature value read from NVM memory - tempR */
	float tempH;	   /* Production Hot Temperature value read from NVM memory - tempH */
	float INT1VR;      /* Room temp 2�s complement of the internal 1V reference value - INT1VR */
	float INT1VH;	   /* Hot temp 2�s complement of the internal 1V reference value - INT1VR */

	float VADCR;	   /* Room Temperature ADC voltage - VADCR */
	float VADCH;	   /* Hot Temperature ADC voltage - VADCH */
	
	float VADC;      /* Voltage calculation using ADC result for Coarse Temp calculation */
	float VADCM;     /* Voltage calculation using ADC result for Fine Temp calculation. */
	float INT1VM;    /* Voltage calculation for reality INT1V value during the ADC conversion */
	
	uint16_t temp_adc_average;
	
	temp_adc_average = temp_average_calculate(temp_adc_sample);
	DEBUG_1_MEMORY.ADC_TEMP = temp_adc_average;
	
	tempR = ROOM_TEMP_VAL_INT + (float)ROOM_TEMP_VAL_DEC/10.0;//�����¶Ȳ���
	tempH = HOT_TEMP_VAL_INT + (float)HOT_TEMP_VAL_DEC/10.0;//�����¶Ȳ���
	
	INT1VR = ADC_REF_MCU - ((float)ROOM_INT1V_VAL * 2.48 / 1000.0);//�����¶Ȳο���ѹ����
	INT1VH = ADC_REF_MCU - ((float)HOT_INT1V_VAL * 2.48 / 1000.0);//�����¶Ȳο���ѹ����
	
	VADCR = ((float)ROOM_ADC_VAL * INT1VR) / 4095.0;//�����¶ȵ�ѹ
	VADCH = ((float)HOT_ADC_VAL * INT1VH) / 4095.0;//�����¶ȵ�ѹ
	
	VADC = ((float)temp_adc_average * ADC_REF_MCU)/ 4095.0;//�޲ο���ѹ�������㵱ǰ�¶ȵ�ѹ
	
	tempC = tempR + (((VADC - VADCR) * (tempH - tempR)) / (VADCH - VADCR));//�޲ο���ѹ�������㵱ǰ�¶�
	
	INT1VM = INT1VR + (((INT1VH - INT1VR) * (tempC - tempR))/(tempH - tempR));//���㵱ǰ�¶Ȳο���ѹ����
	
	VADCM = ((float)temp_adc_average * INT1VM)/ 4095.0;//��ǰ�¶����вο���ѹ�����µ�ѹ
	
	tempF = tempR + (((tempH - tempR)/(VADCH - VADCR)) * (VADCM - VADCR));//��ǰ�¶��´��ο���ѹ�����������¶�
	
	return (unsigned short int)(tempF*256);
}

int main(void)
{
	//step1: init temperature sensor & ADC
	ADC_0_init();
	enable_adc();
	
	//step2: Load local parameters 
	temp_local_parameter();
	
	//step2: sampling
	set_adc_pin();
	delay_us(10);
	read_adc_result();
	
	//step3:calculate
	DEBUG_1_MEMORY.int_TEMPERATURE = l21_temperature_calculate(temp_adc.real_data);
}