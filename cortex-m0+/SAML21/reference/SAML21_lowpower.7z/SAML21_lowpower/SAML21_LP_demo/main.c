#include <atmel_start.h>
#include <hpl_init.h>
#include <hal_sleep.h>

static void cb_eic_exint2(void)
{
}

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	ext_irq_register(PIN_PA02, cb_eic_exint2);
	
	//the 1 step :Active mode implementation
	// Disable BOD33
	SUPC->BOD33.reg &= ~SUPC_BOD33_ENABLE;
	
	// Select BUCK converter as the main voltage regulator in active mode 
	SUPC->VREG.bit.SEL = SUPC_VREG_SEL_BUCK_Val;
	
	// Wait for the regulator switch to be completed 
	while(!(SUPC->STATUS.reg & SUPC_STATUS_VREGRDY));
	
	// Set Performance Level to PL0 as we run @12MHz 
	_set_performance_level(PM_PLCFG_PLSEL_PL0_Val);
	
	
	
	// the 2 step : enter IDLE Sleep
	sleep(PM_SLEEPCFG_SLEEPMODE_IDLE_Val);
	
	
	// the 3 step : enter standy sleep mode
	//Set voltage regurator low power mode efficiency
	SUPC->VREG.bit.LPEFF = 0x01;
	
	//Apply SAM L21 Erratum 15264 
	SUPC->VREG.bit.RUNSTDBY = 0x1;
	SUPC->VREG.bit.STDBYPL0 = 0x1;
	
	sleep(PM_SLEEPCFG_SLEEPMODE_STANDBY_Val);
	
	
	// the 4 step : BACKUP sleep mode implementation
	//configure EXTWAKE[2] Wakeup debounce Counter Value to 32kHZ clock periods
	RSTC->WKDBCONF.reg = RSTC_WKDBCONF_WKDBCNT(RSTC_WKDBCONF_WKDBCNT_2CK32);

	//Configure EXTWAKE[2] Wakeup Polarity to low. 
	RSTC->WKPOL.reg &= ~RSTC_WKPOL_WKPOL(0x4);
	
	
	// Enables EXTWAKE[2] feature
	RSTC->WKEN.reg = RSTC_WKEN_WKEN(0x4);
	
	// Wait for PA02 to be released before entering in BACKUP 
	while((PORT->Group[0].IN.reg & PORT_PA02)==0);
	
	// Enter BACKUP Sleep Mode
	sleep(PM_SLEEPCFG_SLEEPMODE_BACKUP_Val);
	
	/* Replace with your application code */
	while (1) {
	}
}
