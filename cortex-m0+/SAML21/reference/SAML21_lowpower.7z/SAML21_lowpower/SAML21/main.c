#include <atmel_start.h>
#include "temperature_sensor_main.h"

struct io_descriptor *uart_edbg_io;
struct io_descriptor *spi_edbg_io;
volatile bool conversion_done = false;
uint8_t ADC_buffer[2];
float temperature;
uint8_t Datastream_buf[5] = {0x03, 0x00, 0x00, 0x00, 0xFC};

void USART_0_EDBG_init(void)
{
	usart_sync_get_io_descriptor(&USART_0, &uart_edbg_io);
	usart_sync_enable(&USART_0);

	io_write(uart_edbg_io, (uint8_t *)"Hello World!", 12);
}

static void convert_cb_ADC(const struct adc_async_descriptor *const descr, const uint8_t channel)
{
	conversion_done = true;
}

/**
 * Example of using ADC_0 to generate waveform.
 */
void ADC_litht_init(void)
{
	adc_async_register_callback(&ADC_0, 0, ADC_ASYNC_CONVERT_CB, convert_cb_ADC);
	adc_async_enable_channel(&ADC_0, 0);
	//
}

void SPI_DGI_init(void)
{

	spi_m_sync_get_io_descriptor(&SPI_0, &spi_edbg_io);

	spi_m_sync_enable(&SPI_0);
	io_write(uart_edbg_io, (uint8_t *)"\nSPI Init\n", 10);
}

/**
 * Example of using ADC_0 to generate waveform.
 */


int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	/* Replace with your application code */
	USART_0_EDBG_init();
	ADC_litht_init();
	io_write(uart_edbg_io, (uint8_t *)"ADC Init\n", 9);
	temperature_sensors_init();
	io_write(uart_edbg_io, (uint8_t *)"I2C Init\n", 9);
	
	SPI_DGI_init();

	while (1) {
		delay_ms(1000);
		temperature = at30tse75x_read(TEMPERATURE_SENSOR_0);
		
		adc_async_start_conversion(&ADC_0);
		while(!conversion_done);
		adc_async_read_channel(&ADC_0, 0, ADC_buffer, 2);
		
		Datastream_buf[1] =(uint8_t)temperature;
		Datastream_buf[2] = ADC_buffer[0];
		Datastream_buf[2] = ADC_buffer[1];
		io_write(spi_edbg_io, Datastream_buf,5);
		
	}
}
