/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */

#include "driver_examples.h"
#include "driver_init.h"
#include "utils.h"

/**
 * Example of using DIGITAL_GLUE_LOGIC_0.
 */
void DIGITAL_GLUE_LOGIC_0_example(void)
{
	custom_logic_enable();
	/* Customer logic now works. */
}

void delay_example(void)
{
	delay_ms(5000);
}
