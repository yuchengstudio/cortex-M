/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */

#include "driver_init.h"
#include <peripheral_clk_config.h>
#include <utils.h>
#include <hal_init.h>

void DIGITAL_GLUE_LOGIC_0_PORT_init(void)
{

	gpio_set_pin_function(PA04, PINMUX_PA04I_CCL_IN0);

	gpio_set_pin_function(PA08, PINMUX_PA08I_CCL_IN3);

	gpio_set_pin_function(PA09, PINMUX_PA09I_CCL_IN4);

	gpio_set_pin_function(PA10, PINMUX_PA10I_CCL_IN5);

	gpio_set_pin_function(PA19, PINMUX_PA19I_CCL_OUT0);

	gpio_set_pin_function(PA11, PINMUX_PA11I_CCL_OUT1);
}

void DIGITAL_GLUE_LOGIC_0_CLOCK_init(void)
{
	hri_mclk_set_APBDMASK_CCL_bit(MCLK);
	hri_gclk_write_PCHCTRL_reg(GCLK, CCL_GCLK_ID, CONF_GCLK_CCL_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
}

void DIGITAL_GLUE_LOGIC_0_init(void)
{
	DIGITAL_GLUE_LOGIC_0_CLOCK_init();
	custom_logic_init();
	DIGITAL_GLUE_LOGIC_0_PORT_init();
}

void delay_driver_init(void)
{
	delay_init(SysTick);
}

void system_init(void)
{
	init_mcu();

	// GPIO on PB10

	gpio_set_pin_level(LED0,
	                   // <y> Initial level
	                   // <id> pad_initial_level
	                   // <false"> Low
	                   // <true"> High
	                   false);

	// Set pin direction to output
	gpio_set_pin_direction(LED0, GPIO_DIRECTION_OUT);

	gpio_set_pin_function(LED0, GPIO_PIN_FUNCTION_OFF);

	DIGITAL_GLUE_LOGIC_0_init();

	delay_driver_init();
}
