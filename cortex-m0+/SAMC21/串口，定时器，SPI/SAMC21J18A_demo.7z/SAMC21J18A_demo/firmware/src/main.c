/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes


// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************


#define debug_SERCOM5_SPI


bool txflag = false;
unsigned char Txbuf[] = "hello world!";
unsigned char Rxbuf[10];
unsigned char SpiTxbuf[] = {0x55,0xff};

#ifdef debug_TC0
/* This function is called after period expires */
void TC0_Callback_InterruptHandler(TC_TIMER_STATUS status, uintptr_t context)
{
    /* Toggle LED */
    //LED_Toggle();
    //txflag = true;
    
}
#endif
#ifdef debug_SERCOM4_UART
void usartTxhandleer(uintptr_t context)
{
    /* Toggle LED */
    //LED_Toggle();
    
}

void usartRxhandleer(uintptr_t context)
{
    /* Toggle LED */
    LED_Toggle();
    
}
#endif
#ifdef debug_SERCOM5_SPI
void SPIEventHandler(uintptr_t context )
{
    /* De-assert the chip select */
    SPI_SS_Set();
    //isTransferDone = true;
}
#endif

int main ( void )
{
    /* Initialize all modules */
    SYS_Initialize ( NULL );
    /* Register callback function for TC0 period interrupt */
#ifdef debug_TC0
    TC0_TimerCallbackRegister(TC0_Callback_InterruptHandler, (uintptr_t)NULL);
#endif

#ifdef debug_SERCOM4_UART
    /*Register callback function for SERCOM4 UART_TX , UART_RX complete interrrupt*/
    SERCOM4_USART_WriteCallbackRegister(usartTxhandleer ,(uintptr_t)NULL);
    SERCOM4_USART_ReadCallbackRegister(usartRxhandleer ,(uintptr_t)NULL);
#endif
    
#ifdef debug_SERCOM5_SPI
    /*Register callback function for SERCOM5 SPI_TX , SPI_RX complete interrrupt*/
    SERCOM5_SPI_CallbackRegister(SPIEventHandler, (uintptr_t) 0);
#endif
    
#ifdef debug_SERCOM5_SPI
    SERCOM5_SPI_Write(SpiTxbuf, 1);
#endif
    
#ifdef debug_TC0
    /* Start the timer channel 0*/
    TC0_TimerStart();
#endif
    
    while ( true )
    {
        /* Maintain state machines of all polled MPLAB Harmony modules. */
        //SYS_Tasks ( );
#ifdef debug_SERCOM4_UART
        SERCOM4_USART_Read(Rxbuf,1);
        
        if(true == txflag)
        {
          SERCOM4_USART_Write( Txbuf, 12 );
          txflag = false;
        }
#endif
    }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
}


/*******************************************************************************
 End of File
*/

