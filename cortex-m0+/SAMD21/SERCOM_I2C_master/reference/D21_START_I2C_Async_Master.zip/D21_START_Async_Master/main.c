#include <atmel_start.h>

/*LED0 pin*/
#define LED0 GPIO(GPIO_PORTB, 30)

/* Initialize the variables */
struct io_descriptor *I2C_0_io_master;

uint8_t rx_str[2];

volatile bool Is_Rx_Done = false;

/* Master receive complete callback */
void I2C_0_rx_complete_cb(struct i2c_m_async_desc *const i2c)
{
	Is_Rx_Done = true;
}

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	/* configure led0 */
	gpio_set_pin_direction(LED0, GPIO_DIRECTION_OUT);
	gpio_set_pin_level(LED0, true);
	gpio_set_pin_function(LED0, GPIO_PIN_FUNCTION_OFF);
	
	/* Initialize I2C slave */
	i2c_m_async_get_io_descriptor(&I2C_0, &I2C_0_io_master);
	
	/* Enable master */
	i2c_m_async_enable(&I2C_0);
	
	/* register callback */
	i2c_m_async_register_callback(&I2C_0, I2C_M_ASYNC_RX_COMPLETE, (FUNC_PTR)I2C_0_rx_complete_cb);
	
	/* set the slave address */
	i2c_m_async_set_slaveaddr(&I2C_0, 0x12, I2C_M_SEVEN);
	
	/* Start the I2C transaction by sending the slave address */
	io_read(I2C_0_io_master, &rx_str[0], 1);
	
	/* Wait for transaction to be completed */
	while(Is_Rx_Done == false);
	Is_Rx_Done = false;
	
	/* delay to send the next byte */
	delay_ms(1);
	
	/* start to receive the next byte */
	io_read(I2C_0_io_master, &rx_str[1], 1);
	
	/* wait till transaction complete */
	while(Is_Rx_Done == false);
	
	while (1) {
		
		/* If the received byte is as expected toggle LED */
		if(rx_str[0] == 1 && rx_str[1] == 2)
		{
			gpio_toggle_pin_level(LED0);
			delay_ms(100);	
		}
	}
}
