/*******************************************************************************
* Copyright (C) 2019 Microchip Technology Inc. and its subsidiaries.
*
* Subject to your compliance with these terms, you may use Microchip software
* and any derivatives exclusively with Microchip products. It is your
* responsibility to comply with third party license terms applicable to your
* use of third party software (including open source software) that may
* accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
* EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
* WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
* PARTICULAR PURPOSE.
*
* IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
* INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
* WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
* BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
* FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
* ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#include <string.h>
#include <stdio.h>


#define LED_ON                      LED_Clear
#define LED_OFF                     LED_Set
#define LED_TOGGLE                  LED_Toggle

#define CONF_CPU_FREQUENCY    48000000 // 48MHz main clock

/* Flash address for erase/write test */
#define FLASH_TEST_ADDRESS    0x8000U

/* Global ticks since start of application */
volatile uint32_t g_ticks = 0;

uint32_t start_tick = 0;
uint32_t end_tick = 0;
uint32_t flash_wait_cnt = 0;

uint8_t flash_src_data[NVMCTRL_FLASH_PAGESIZE];


void populate_buffer(uint8_t* flash_src_data)
{
    int i = 0;

    for (i = 0; i < (NVMCTRL_FLASH_PAGESIZE); i++)
    {
        *(flash_src_data + i) = i;
    }
}


/**
 *  \brief Handler for System Tick interrupt.
 *
 *  Process System Tick Event
 *  Increments the g_ticks counter.
 */
__attribute__ ((section(".ramfunc")))
void SysTick_Handler(void)
{
    g_ticks++;
}


/**
 *  \brief NVMCTRL Erase a row, execute code from RAM
 */
__attribute__ ((section(".ramfunc")))
bool NVMCTRL_RowErase_from_ram( uint32_t address )
{
    /* Set address and command */
    NVMCTRL_REGS->NVMCTRL_ADDR = address >> 1;

    NVMCTRL_REGS->NVMCTRL_CTRLA = NVMCTRL_CTRLA_CMD_ER_Val | NVMCTRL_CTRLA_CMDEX_KEY;

    /* Wait NVMCTRL ready */
    flash_wait_cnt = 0;
    while (!(NVMCTRL_REGS->NVMCTRL_INTFLAG & NVMCTRL_INTFLAG_READY_Msk))
    {
        flash_wait_cnt++;
    }

    return true;
}


/**
 *  \brief NVMCTRL write a page, execute code from RAM
 */
__attribute__ ((section(".ramfunc")))
bool NVMCTRL_PageWrite_from_ram( uint32_t *data, const uint32_t address )
{
    uint32_t i = 0;
    uint32_t * paddress = (uint32_t *)address;

    /* writing 32-bit data into the given address */
    for (i = 0; i < (NVMCTRL_FLASH_PAGESIZE/4); i++)
    {
        *paddress++ = data[i];
    }

     /* Set address and command */
    NVMCTRL_REGS->NVMCTRL_ADDR = address >> 1;

    NVMCTRL_REGS->NVMCTRL_CTRLA = NVMCTRL_CTRLA_CMD_WP_Val | NVMCTRL_CTRLA_CMDEX_KEY;

    /* Wait NVMCTRL ready */
    flash_wait_cnt = 0;
    while (!(NVMCTRL_REGS->NVMCTRL_INTFLAG & NVMCTRL_INTFLAG_READY_Msk))
    {
        flash_wait_cnt++;
    }

    return true;
}

// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************

int main ( void )
{
    /* Initialize all modules */
    SYS_Initialize ( NULL );

    printf("\r\n==== Example of executing Code from RAM ====\r\n");
    printf("  - Vector table (VTOR) is put in RAM\r\n");
    printf("  - SysTick_Handler is put in RAM\r\n");

    /* Configure systick for 0.01 ms */
    if (SysTick_Config(CONF_CPU_FREQUENCY / 100000)) {
        printf("ERROR: Systick configuration error\r\n");
        while (1);
    }

    LED_OFF();

    /* Test 1: Execute flash erase from RAM */
    printf("\r\n---- Execute flash erase from RAM ----\r\n");
    start_tick = g_ticks;
    NVMCTRL_RowErase_from_ram(FLASH_TEST_ADDRESS);
    end_tick = g_ticks;
    printf("Flash wait count during flash row erase: %u\r\n", (unsigned int)flash_wait_cnt);
    printf("Start / End tick of flash row erase: %u / %u ticks! Tick delta = %u\r\n",
        (unsigned int)start_tick, (unsigned int)end_tick, (unsigned int)(end_tick - start_tick));

    /* Test 2: Execute flash erase from Flash */
    printf("\r\n---- Execute flash erase from Flash ----\r\n");
    start_tick = g_ticks;
    NVMCTRL_RowErase(FLASH_TEST_ADDRESS);
    flash_wait_cnt = 0;
    while(NVMCTRL_IsBusy())
    {
        flash_wait_cnt++;
    }
    end_tick = g_ticks;
    printf("Flash wait count during flash row erase: %u\r\n", (unsigned int)flash_wait_cnt);
    printf("Start / End tick of flash row erase: %u / %u ticks! Tick delta = %u\r\n",
        (unsigned int)start_tick, (unsigned int)end_tick, (unsigned int)(end_tick - start_tick));

    /* Test 3: flash page write from RAM */
    /*Populate random flash_src_data to programmed*/
    populate_buffer(flash_src_data);

    printf("\r\n---- Execute flash page write ----\r\n");
    start_tick = g_ticks;
#if 1
    NVMCTRL_PageWrite_from_ram((uint32_t *)flash_src_data, FLASH_TEST_ADDRESS);
#else
    NVMCTRL_PageWrite((uint32_t *)flash_src_data, FLASH_TEST_ADDRESS);
    flash_wait_cnt = 0;
    while(NVMCTRL_IsBusy())
    {
        flash_wait_cnt++;
    }
#endif
    end_tick = g_ticks;
    printf("Flash wait count during flash page write: %u\r\n", (unsigned int)flash_wait_cnt);
    printf("Start / End tick of flash page write: %u / %u ticks! Tick delta = %u\r\n",
        (unsigned int)start_tick, (unsigned int)end_tick, (unsigned int)(end_tick - start_tick));

    /* Verify the programmed content*/
    if (!memcmp(flash_src_data, (void *)FLASH_TEST_ADDRESS, NVMCTRL_FLASH_PAGESIZE))
    {
        LED_ON();
    }

    while ( true )
    {
        /* Maintain state machines of all polled MPLAB Harmony modules. */
        SYS_Tasks ( );
    }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
}


/*******************************************************************************
 End of File
*/

