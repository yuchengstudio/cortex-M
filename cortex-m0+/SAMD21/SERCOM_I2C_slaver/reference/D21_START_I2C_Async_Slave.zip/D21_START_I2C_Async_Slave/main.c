#include <atmel_start.h>

/* LED0 pin */
#define LED0 GPIO(GPIO_PORTB, 30)

/* Initialize static variables */
static struct io_descriptor *io_slave;

uint8_t tx_index = 0;

static uint8_t I2C_0_example_str[2] = {1,2};

volatile bool Is_tx_done = false;

/* Transfer complete callback */
static void I2C_0_tx_complete_cb(const struct i2c_s_async_descriptor *const descr)
{
	Is_tx_done = true;
}

/* This callback will be received when the master initiates the transaction by sending the address */
static void I2C_0_tx_pending_cb(const struct i2c_s_async_descriptor *const descr)
{
	io_write(io_slave, (I2C_0_example_str + tx_index), 1);
}

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	/* configure led0 */
	gpio_set_pin_direction(LED0, GPIO_DIRECTION_OUT);
	gpio_set_pin_level(LED0, true);
	gpio_set_pin_function(LED0, GPIO_PIN_FUNCTION_OFF);
	
	/* Configure Slave Callbacks */
	i2c_s_async_get_io_descriptor(&I2C_0, &io_slave);
	i2c_s_async_register_callback(&I2C_0, I2C_S_TX_COMPLETE, I2C_0_tx_complete_cb);
	i2c_s_async_register_callback(&I2C_0, I2C_S_TX_PENDING, I2C_0_tx_pending_cb);
	
	/* Enable slave */
	i2c_s_async_enable(&I2C_0);

	/* wait for transaction to be completed */
	while(Is_tx_done == false);
	tx_index = 1;
	Is_tx_done = false;
	
	/* wait for next byte to be sent */
	while(Is_tx_done == false);

	while (1) {
		/* when 2 bytes are sent successfully toggle LED */
		gpio_toggle_pin_level(LED0);
		delay_ms(1000);		
	}
}
