/**
 * \file
 *
 * \brief SAM LED Toggle Example
 *
 * Copyright (c) 2012-2018 Microchip Technology Inc. and its subsidiaries.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip
 * software and any derivatives exclusively with Microchip products.
 * It is your responsibility to comply with third party license terms applicable
 * to your use of third party software (including open source software) that
 * may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE
 * LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
 * LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
 * SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT
 * ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
 * RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
 * THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * \asf_license_stop
 *
 */

/**
 * \mainpage SAM LED Toggle Example
 * See \ref appdoc_main "here" for project documentation.
 * \copydetails appdoc_preface
 *
 *
 * \page appdoc_preface Overview
 * This application demonstrates a simple example to toggle the board LED.
 */

/**
 * \page appdoc_main SAM LED Toggle Example
 *
 * Overview:
 * - \ref appdoc_sam0_led_toggle_app_intro
 * - \ref appdoc_sam0_led_toggle_app_usage
 * - \ref appdoc_sam0_led_toggle_app_compinfo
 * - \ref appdoc_sam0_led_toggle_app_contactinfo
 *
 * \section appdoc_sam0_led_toggle_app_intro Introduction
 * This application demonstrates a simple example to toggle the board LED.
 *
 * This application has been tested on following boards:
 * - SAM D20/D21/R21/D11/L21/L22/R30 Xplained Pro
 * - SAM D10 Xplained Mini
 * - SAMR21ZLL-EK
 *
 * \section appdoc_sam0_led_toggle_app_usage Usage
 * The application uses system timer to generate periodic interrupts, once the
 * interrupt occurs, LED0 will toggle.
 *
 * \section appdoc_sam0_led_toggle_app_compinfo Compilation Info
 * This software was written for the GNU GCC and IAR for ARM.
 * Other compilers may or may not work.
 *
 * \section appdoc_sam0_led_toggle_app_contactinfo Contact Information
 * For further information, visit
 * <a href="http://www.atmel.com">http://www.atmel.com</a>.
 */
/*
 * Support and FAQ: visit <a href="https://www.microchip.com/support/">Microchip Support</a>
 */

#include <asf.h>


/** Handler for the device SysTick module, called when the SysTick counter
 *  reaches the set period.
 *
 *  \note As this is a raw device interrupt, the function name is significant
 *        and must not be altered to ensure it is hooked into the device's
 *        vector table.
 */
void tc_callback_to_toggle_tc(struct tc_module *const module_inst);
struct tc_module tc_instance;
#define CONF_TCTEC_MODULE  TC3
#define LED_FUNCTION port_pin_toggle_output_level(LED_0_PIN)
#define LED_ON_FUNCTION port_pin_set_output_level(LED_0_PIN,true)


void jump_application(uint32_t flash_address)
{
	 uint32_t *app_check_address_ptr; 
 
	 /* Read the first location of application section 
		which contains the address of stack pointer.
	  * If it is 0xFFFFFFFF then the application section is empty. */
	 app_check_address_ptr = (uint32_t *)flash_address;
	 if(*app_check_address_ptr == 0xFFFFFFFF)
	 {
		  //STATE = BOOTLOADER_UNLOCK;
		  //i2c_slave_packet.tx_data[0] = 0Xff;
		  return;
	 }
	 /* Pointer to the Application Section */
	 void (*application_code_entry)(void);
	 /* Rebase the Stack Pointer */
	 __set_MSP(*(uint32_t *) flash_address);
	 /* Rebase the vector table base address */
	 SCB->VTOR = ((uint32_t) flash_address & SCB_VTOR_TBLOFF_Msk);
	 /* Load the Reset Handler address of the application */
	 application_code_entry = (void (*)(void))(unsigned *)(*(unsigned *)(flash_address + 4));
	 /* Jump to user Reset Handler in the application */
	 application_code_entry(); 
}

unsigned int b = 0;
void tc_callback_to_toggle_tc(
struct tc_module *const module_inst)
{

	LED_FUNCTION;
	b++;
}

void configure_tc(void)
{
	//! [setup_config]
	//! [setup_config]
	struct tc_config config_tc;
	//! [setup_config]
	//! [setup_config_defaults]
	tc_get_config_defaults(&config_tc);
	//! [setup_config_defaults]

	//! [setup_change_config]
	config_tc.counter_size = TC_COUNTER_SIZE_8BIT;
	config_tc.clock_source = GCLK_GENERATOR_2;
	config_tc.clock_prescaler = TC_CLOCK_PRESCALER_DIV16;
	config_tc.counter_8_bit.period = 250;//5ms 110ms
	config_tc.counter_8_bit.value = 0;
	//! [setup_change_config]

	//! [setup_set_config]
	(void)tc_init(&tc_instance, CONF_TCTEC_MODULE, &config_tc);
	//! [setup_set_config]

	//! [setup_enable]
	tc_enable(&tc_instance);
	//! [setup_enable]

	//! [setup_register_callback]
	(void)tc_register_callback(&tc_instance, tc_callback_to_toggle_tc, TC_CALLBACK_OVERFLOW);

	//! [setup_enable_callback]
	(void)tc_enable_callback(&tc_instance, TC_CALLBACK_OVERFLOW);
	//! [setup_enable_callback]
}


void SysTick_Handler(void)
{
	//port_pin_toggle_output_level(LED_0_PIN);
}

/** Configure LED0, turn it off*/
static void config_led(void)
{
	struct port_config pin_conf;
	port_get_config_defaults(&pin_conf);

	pin_conf.direction  = PORT_PIN_DIR_OUTPUT;
	port_pin_set_config(LED_0_PIN, &pin_conf);
	port_pin_set_output_level(LED_0_PIN, LED_0_INACTIVE);
}

int main(void)
{
	uint16_t i,j = 0;
	system_init();

	/*Configure system tick to generate periodic interrupts */
	//SysTick_Config(system_gclk_gen_get_hz(GCLK_GENERATOR_0));	
	Enable_global_interrupt();
	config_led();
	configure_tc();
	while (true)
	{
		if(b > 20)
		{
			b = 0;
			Disable_global_interrupt();
			//system_reset();
			jump_application(0);
			
		}
		
		//for (i=0;i<1000;i++)
		//{
			//j++;
		//}
		//jump_application(0);
	}
}
